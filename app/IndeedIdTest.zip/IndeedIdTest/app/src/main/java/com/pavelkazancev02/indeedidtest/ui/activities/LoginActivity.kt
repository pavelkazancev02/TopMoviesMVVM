package com.pavelkazancev02.indeedidtest.ui.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.pavelkazancev02.indeedidtest.R

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
